CREATE TABLE EMPLOYEES(
	EmployeeId int,
	EmployeeName varchar(100)
)


CREATE TABLE EMPLOYEES(	EmployeeId int,	EmployeeName varchar(100))


DROP TABLE EMPLOYEES