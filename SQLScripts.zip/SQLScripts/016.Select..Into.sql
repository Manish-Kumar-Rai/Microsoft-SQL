

SELECT * FROM DimProduct

SELECT * INTO DimProduct_Bk FROM DimProduct

SELECT * INTO DimProduct_Bk2 FROM DimProduct
WHERE Color = 'Red'


select * from DimProduct_Bk3


SELECT * INTO DimProduct_Bk3 FROM DimProduct
WHERE 1=2


SELECT ProductKey,EnglishProductName,ListPrice
INTO DimProduct_Bk4 FROM DimProduct

SELECT * FROM DimProduct_Bk4