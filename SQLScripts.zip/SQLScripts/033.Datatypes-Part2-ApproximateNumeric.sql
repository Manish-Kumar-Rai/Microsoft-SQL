


create table ApproNumericDataTypes(
	price decimal,
	cost numeric

)

create table ApproNumericDataTypes(
	price decimal(38,38),
	cost numeric(38,38)

)


insert into ApproNumericDataTypes(price) values(1929.92